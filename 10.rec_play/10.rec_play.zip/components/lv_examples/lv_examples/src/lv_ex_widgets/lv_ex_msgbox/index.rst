C
^

Simple Message box 
"""""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_msgbox/lv_ex_msgbox_1.*
  :alt: Message box example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_msgbox/lv_ex_msgbox_1.c
      :language: c



Modal 
""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_msgbox/lv_ex_msgbox_2.*
  :alt: Modal Message box example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_msgbox/lv_ex_msgbox_2.c
      :language: c


MicroPython
^^^^^^^^^^^

No examples yet.
