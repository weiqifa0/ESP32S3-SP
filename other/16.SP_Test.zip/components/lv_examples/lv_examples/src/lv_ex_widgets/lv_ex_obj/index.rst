C
^

Base obejcts with custom styles 
""""""""""""""""""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_obj/lv_ex_obj_1.*
  :alt: Simeple Base object example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_obj/lv_ex_obj_1.c
      :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
